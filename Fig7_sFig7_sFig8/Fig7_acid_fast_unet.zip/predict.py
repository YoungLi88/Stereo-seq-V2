import os
import numpy as np
import torch
import cv2
import argparse
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms
import torch.nn as nn
from tqdm import tqdm
from model import Unet

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
print(device)
print(torch.cuda.current_device())

class RunDataset(Dataset):
    def __init__(self, dataset_dir, transform=None):
        """
        Args:
            dataset_dir : path to the dataset
            transform (callable, optional): Optional transform to be applied
                                            on a sample.
        """
        self.dataset_dir = dataset_dir
        self.list_dir = os.listdir(self.dataset_dir)
        self.transform = transform
    
    def __len__(self):
        return len(self.list_dir)
    
    def __getitem__(self, image_id):
        file_name = self.list_dir[image_id]
        image = cv2.imread(os.path.join(self.dataset_dir, file_name))
        sample = {"image": image, "image_id": image_id}
        
        if self.transform:
            image = sample["image"]
            image = self.transform(image)
            sample = {"image": image, "image_id": file_name}
        
        return sample

def save_prediction(sample_batched, dout):
    """Save image with landmarks and predicted masks for a batch of samples."""
    pred_masks_batch = sample_batched['pred_masks'].numpy().astype(bool)
    batch_size = len(pred_masks_batch)
    for i in range(batch_size):
        cv2.imwrite(os.path.join(dout, sample_batched['name'][0]), 
                   np.squeeze(pred_masks_batch[i].transpose((1, 2, 0))).astype(np.uint8)*255)

def read_flags():
    """Return Global variables"""
    parser = argparse.ArgumentParser()

    parser.add_argument(
        "--logs_path",
        required=True,
        help="path to the model checkpoint file")

    parser.add_argument(
        "--input_dir",
        required=True,
        help="path to the input dataset directory")

    parser.add_argument(
        "--output_dir",
        required=True,
        help="path to save the prediction results")

    return parser.parse_args()

def main(FLAGS):
    # HyperParameters
    val_batch_size = 1
    num_classes = 2

    # load the model
    model = Unet(3, num_classes)
    if torch.cuda.device_count() > 1:
        model = nn.DataParallel(model, device_ids=[0,1])
    model.to(device)
    optimizer = torch.optim.SGD(model.parameters(),
                          lr=0.01,
                          momentum=0.9,
                          weight_decay=0.0005)
    checkpoint = torch.load(FLAGS.logs_path)
    model.load_state_dict(checkpoint["model_state_dict"])
    optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
    epoch = checkpoint['epoch']
    loss = checkpoint['loss']
    model.eval()

    # prepare dataset and dataloader
    trans = transforms.Compose([
        transforms.ToPILImage(),
        transforms.Resize((512,512)),
        transforms.ToTensor()
    ])
    full_dset = RunDataset(FLAGS.input_dir, transform=trans)
    full_loader = DataLoader(full_dset, batch_size=val_batch_size, shuffle=False, num_workers=0)

    # create output directory if not exists
    os.makedirs(FLAGS.output_dir, exist_ok=True)

    # run prediction
    for index, sampled_batch in tqdm(enumerate(full_loader)):
        inputs = sampled_batch["image"].to(device)  # N,C,H,W
        pred = model(inputs)
        _, predicted = torch.max(pred, 1)
        predicted = torch.unsqueeze(predicted, 1)
        sample = {"pred_masks": predicted.cpu(), "name": sampled_batch["image_id"]}
        save_prediction(sample, FLAGS.output_dir)

if __name__ == '__main__':
    flags = read_flags()
    main(flags)
