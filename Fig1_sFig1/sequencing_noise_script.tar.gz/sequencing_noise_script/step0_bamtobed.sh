sample=""
bedtools bamtobed -i ./bam/${sample}.bam > ./bam/${sample}.bed
awk '$5 == 255' ./bam/${sample}.bed > ./bam/${sample}_filtered.bed
