sample="visium"

bedtools intersect -a ./bam/${sample}_filtered.bed -b merged.bed  -s -wa -wb|awk '{print $4, $10}' > ${sample}.txt 
