sample="SRR18685817"

bedtools intersect -a ./${sample}_intergenic.txt  -b ENCFF600PBT.bed  -wa -wb|awk '{print $4, $10}' > ${sample}_chrom.txt 
