sample="visium"
#Count the number of rows with exon, intron, intergenic, and utr in the second column and output them as a table file
awk '
{
    #Extract the region type (ignore the numeric part)
    region_type = $2
    gsub(/[0-9]/, "", region_type)
    
    # Count the number of rows for each region type
    if (region_type == "exon" || region_type == "intron" || region_type == "intergenic" || region_type == "utr") {
        count[region_type]++
    }
}
END {
    
    print "RegionType\tCount"
    
    # Output statistical results
    for (type in count) {
        print type "\t" count[type]
    }
}' ${sample}_rank.txt > ${sample}_region_counts.txt

