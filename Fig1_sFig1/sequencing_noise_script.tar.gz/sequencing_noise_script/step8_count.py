import pandas as pd
import glob
import os

folder_path = "./"
#Get the paths of all .txt files in a folder
txt_files = glob.glob(os.path.join(folder_path, "*_chrom.txt"))

for file_path in txt_files:
    #Extract file name (without path and extension)）
    file_name = os.path.splitext(os.path.basename(file_path))[0]  
    # Read the file and store it into a DataFrame
    tmp = pd.read_csv(file_path, sep=" ", header = None) 
    tmp[1] = tmp[1].apply(lambda x : "Enh" if x in ['EnhPr','EnhPois','Enh','EnhLo','EnhG'] else x )
    tmp[1] = tmp[1].apply(lambda x : "tss" if x in ['TssFlnk','TssBiv','Tss'] else x )
    tmp[1] = tmp[1].apply(lambda x : "ReprPC" if x in ['ReprPCWk','ReprPC'] else x )
    tmp[1] = tmp[1].apply(lambda x : "Tx" if x in ['TxWk','Tx'] else x )
    tmp[1] = tmp[1].apply(lambda x : "quies" if x in ['QuiesG','Quies','Quies2','Quies3','Quies4'] else x )
    tmp[1] = tmp[1].apply(lambda x : "Het" if x in ['Het'] else x )
    tmp = tmp.drop_duplicates()
    counts = pd.DataFrame(tmp[1].value_counts())
    counts.columns = [file_name]
    counts.to_csv(f"./{file_name}_chrom_counts.txt")

folder_path = "./"

txt_files = glob.glob(os.path.join(folder_path, "*_chrom_chrom_counts.txt"))
df_list = []
for file_path in txt_files:
    file_name = os.path.splitext(os.path.basename(file_path))[0]
    sample = file_name.split("_")[0]
    tmp = pd.read_csv(file_path, sep=",",index_col = 0)
    tmp.columns = [sample]
    df_list.append(tmp)  
df_count = pd.concat(df_list,axis = 1)
df_count = df_count.T
df_count = df_count.sort_index()
df_count = df_count.T
df_count = df_count.apply(lambda col: col / col.sum(), axis=0)
df_count.to_csv("intergenic_chrom_state.txt",sep = "\t")
