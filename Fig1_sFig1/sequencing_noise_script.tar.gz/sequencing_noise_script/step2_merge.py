import pandas as pd

#Read four BED files
exons = pd.read_csv('exons.bed', sep='\t', header=None, names=['chrom', 'start', 'end', 'name', 'score', 'strand'])
introns = pd.read_csv('introns.bed', sep='\t', header=None, names=['chrom', 'start', 'end', 'name', 'score', 'strand'])
intergenic = pd.read_csv('intergenic.bed', sep='\t', header=None, names=['chrom', 'start', 'end', 'name', 'score', 'strand'])
utr = pd.read_csv('utr.bed', sep='\t', header=None, names=['chrom', 'start', 'end', 'name', 'score', 'strand'])

#merge four BED files
merged_bed = pd.concat([exons, introns, intergenic, utr], ignore_index=True)

#Sort by chromosome and start position
merged_bed = merged_bed.sort_values(by=['chrom', 'start'])

merged_bed.to_csv('merged.bed', sep='\t', index=False, header=False)

