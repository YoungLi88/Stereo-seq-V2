sample="visium"
# split file
split -n l/10 --additional-suffix=".txt" "${sample}.txt" "${sample}_part_"

#Process each subfile in parallel
parallel -j 5 "step4_process_script.py {} {}.rank" ::: "${sample}_part_"*.txt

# merge file
cat "${sample}_part_"*.txt.rank > "${sample}_rank.txt"

# Remove temporary files
rm "${sample}_part_"*.txt "${sample}_part_"*.txt.rank
