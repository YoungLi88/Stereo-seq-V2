import sys
from collections import defaultdict

# 定义优先级
priority = {'exon': 4, 'intron': 3, 'utr': 2, 'intergenic': 1}

# 初始化字典存储结果
result = defaultdict(dict)

# 输入文件和输出文件
input_file = sys.argv[1]
output_file = sys.argv[2]

# 逐行读取文件
with open(input_file, 'r') as f:
    for line in f:
        reads_id, region = line.strip().split()
        # 提取区域类型（忽略数字部分）
        region_type = ''.join([char for char in region if not char.isdigit()])
        # 获取当前区域的优先级
        current_priority = priority.get(region_type, 0)
        # 如果reads_id不在字典中，或者当前优先级更高，则更新
        if reads_id not in result or current_priority > result[reads_id]['priority']:
            result[reads_id] = {'region': region, 'priority': current_priority}

# 将结果写入文件
with open(output_file, 'w') as f:
    for reads_id, info in result.items():
        f.write(f"{reads_id}\t{info['region']}\n")

