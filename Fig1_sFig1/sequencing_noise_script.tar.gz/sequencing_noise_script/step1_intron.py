import pandas as pd
import re
def parse_attribute(attr):
    attr_dict = {}
    for item in attr.split(';'):
        if item.strip():
            key, value = item.strip().split(' ')
            attr_dict[key] = value.strip('"')
    return attr_dict


gtf_file = "/genome/10x/mm10/refdata-gex-mm10-2020-A/genes/genes.gtf"
gtf_columns = ['seqname', 'source', 'feature', 'start', 'end', 'score', 'strand', 'frame', 'attribute']
gtf_df = pd.read_csv(gtf_file, sep='\t', comment='#', header=None, names=gtf_columns)


exon_df = gtf_df[gtf_df['feature'] == 'exon']

#Parse the attribute column to extract gene_id and transcript_id
def parse_attribute(attr):
    attr_dict = {}
    for item in attr.split(';'):
        if item.strip():
            key, value = item.strip().split(' ')
            attr_dict[key] = value.strip('"')
    return attr_dict

exon_df['attribute_dict'] = exon_df['attribute'].apply(parse_attribute)
exon_df['gene_id'] = exon_df['attribute_dict'].apply(lambda x: x.get('gene_id', ''))
exon_df['transcript_id'] = exon_df['attribute_dict'].apply(lambda x: x.get('transcript_id', ''))

# Group by gene_id, transcript_id, seqname, strand
grouped = exon_df.groupby(['gene_id', 'transcript_id', 'seqname', 'strand'])

# Extract intronic regions
intron_list = []
for name, group in grouped:
    group = group.sort_values(by=['seqname', 'start'])  #Sort by chromosome first, then by start
    if len(group) >= 2:  
        for i in range(1, len(group)):
            intron_start = group.iloc[i-1]['end'] + 1
            intron_end = group.iloc[i]['start'] - 1
            if intron_start < intron_end:
                intron_list.append([group.iloc[i]['seqname'], intron_start, intron_end, '.', '0', group.iloc[i]['strand']])


intron_df = pd.DataFrame(intron_list, columns=['chrom', 'start', 'end', 'name', 'score', 'strand'])


intron_df.to_csv('introns.bed', sep='\t', index=False, header=False)

