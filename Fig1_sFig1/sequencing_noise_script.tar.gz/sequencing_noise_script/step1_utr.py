import pandas as pd
import re


gtf_file = "/genome/10x/mm10/refdata-gex-mm10-2020-A/genes/genes.gtf"
gtf_columns = ['seqname', 'source', 'feature', 'start', 'end', 'score', 'strand', 'frame', 'attribute']

gtf_df = pd.read_csv(gtf_file, sep='\t', comment='#', header=None, names=gtf_columns)

utr_df = gtf_df[gtf_df['feature'].isin(["UTR","3'UTR", "5'UTR", "three_prime_utr", "five_prime_utr"])]

utr_bed = utr_df[['seqname', 'start', 'end', 'attribute', 'score', 'strand']]
utr_bed.columns = ['chrom', 'start', 'end', 'name', 'score', 'strand']

utr_bed['name'] = ['utr' + str(i+1) for i in range(len(utr_bed))]


utr_bed.to_csv('utr.bed', sep='\t', index=False, header=False)

