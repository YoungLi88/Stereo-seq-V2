sample="CRR1252512"

awk '$2 ~ /intergenic/ {print $1}' ${sample}_rank.txt | grep -F -f - ./bam/${sample}_filtered.bed > ${sample}_intergenic.txt
