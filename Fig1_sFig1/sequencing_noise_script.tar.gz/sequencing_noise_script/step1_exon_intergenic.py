import pandas as pd

# Read GTF Files
gtf_file = '/genome/10x/mm10/refdata-gex-mm10-2020-A/genes/genes.gtf'
gtf_columns = ['seqname', 'source', 'feature', 'start', 'end', 'score', 'strand', 'frame', 'attribute']
gtf_df = pd.read_csv(gtf_file, sep='\t', comment='#', header=None, names=gtf_columns)

# Extract exon region
exon_df = gtf_df[gtf_df['feature'] == 'exon']
exon_bed = exon_df[['seqname', 'start', 'end', 'attribute', 'score', 'strand']]
exon_bed.columns = ['chrom', 'start', 'end', 'name', 'score', 'strand']

#Assign unique IDs to exon regions (exon1, exon2, ...)
exon_bed['name'] = ['exon' + str(i+1) for i in range(len(exon_bed))]

# Output exon area as BED file
exon_bed.to_csv('exons.bed', sep='\t', index=False, header=False)


#Extract the start, end position and chain information of all genes
gene_df = gtf_df[gtf_df['feature'] == 'gene']
gene_df = gene_df[['seqname', 'start', 'end', 'strand']]
gene_df.columns = ['chrom', 'start', 'end', 'strand']

# Group by chromosome and sort the gene positions
gene_df = gene_df.sort_values(by=['chrom', 'start'])
# Calculate the region between genes
intergenic_list = []
for (chrom, strand), group in gene_df.groupby(['chrom', 'strand']):
    #Initialize the end position of the previous gene
    prev_end = 0
    for _, row in group.iterrows():
        # The starting position of the current gene
        curr_start = row['start']
        # If the start position of the current gene is greater than the end position of the previous gene, there is an intergenic region
        if curr_start > prev_end:
            intergenic_list.append([chrom, prev_end, curr_start, '.', '0', strand])
        # Update the end position of the previous gene
        prev_end = row['end']

e
intergenic_bed = pd.DataFrame(intergenic_list, columns=['chrom', 'start', 'end', 'name', 'score', 'strand'])
#Assign unique IDs to intergenic regions (intergenic1, intergenic2, ...)
intergenic_bed['name'] = ['intergenic' + str(i+1) for i in range(len(intergenic_bed))]

intergenic_bed.to_csv('intergenic.bed', sep='\t', index=False, header=False)

